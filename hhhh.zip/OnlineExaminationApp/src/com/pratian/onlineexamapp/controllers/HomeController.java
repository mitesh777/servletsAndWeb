package com.pratian.onlineexamapp.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {
	
	@RequestMapping(value = "/")
	public String home() {
		return "home";
	}
	
	@RequestMapping(value = "/home")
	public String home123() {
		return "home";
	}
	
	@RequestMapping(value = "/home.html", method = RequestMethod.POST)
	public String home123(@RequestParam("airlineId") long id,Model model) {
		
		return "home";
	}
}
